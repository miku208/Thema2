# Pterodactyl Nightcore Theme

Install script:
```sh
bash <(curl https://raw.githubusercontent.com/NoPro200/Pterodactyl_Nightcore_Theme/main/install.sh)
```

---
Screenshots:
### Mainpage
![Mainpage](https://raw.githubusercontent.com/NoPro200/Pterodactyl_Nightcore_Theme/main/images/Serverliste.png "Mainpage")
### Login
![Login](https://raw.githubusercontent.com/NoPro200/Pterodactyl_Nightcore_Theme/main/images/Login.png "Login")
### Files
![Files](https://raw.githubusercontent.com/NoPro200/Pterodactyl_Nightcore_Theme/main/images/Files.png "Files")
### Editor
![Editor](https://raw.githubusercontent.com/NoPro200/Pterodactyl_Nightcore_Theme/main/images/Editor.png "Editor")
### Terminal
![Terminal](https://raw.githubusercontent.com/NoPro200/Pterodactyl_Nightcore_Theme/main/images/Terminal.png "Terminal")